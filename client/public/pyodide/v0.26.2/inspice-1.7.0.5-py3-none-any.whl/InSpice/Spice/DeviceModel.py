####################################################################################################
#
# InSpice - A Spice Package for Python
# Copyright (C) 2021 Fabrice Salvaire
# Copyright (C) 2025 Innovoltive
# Modified by Innovoltive on April 18, 2025
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Affero General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
####################################################################################################

__all__ = ['DeviceModel']

####################################################################################################

from .StringTools import join_dict

####################################################################################################

class DeviceModel:

    """This class implements a device model.

    Ngspice model types:

    +------+-------------------------------+
    | Code + Model Type                    |
    +------+-------------------------------+
    | R    + Semiconductor resistor model  |
    +------+-------------------------------+
    | C    + Semiconductor capacitor model |
    +------+-------------------------------+
    | L    + Inductor model                |
    +------+-------------------------------+
    | SW   + Voltage controlled switch     |
    +------+-------------------------------+
    | CSW  + Current controlled switch     |
    +------+-------------------------------+
    | URC  + Uniform distributed RC model  |
    +------+-------------------------------+
    | LTRA + Lossy transmission line model |
    +------+-------------------------------+
    | D    + Diode model                   |
    +------+-------------------------------+
    | NPN  + NPN BJT model                 |
    +------+-------------------------------+
    | PNP  + PNP BJT model                 |
    +------+-------------------------------+
    | NJF  + N-channel JFET model          |
    +------+-------------------------------+
    | PJF  + P-channel JFET model          |
    +------+-------------------------------+
    | NMOS + N-channel MOSFET model        |
    +------+-------------------------------+
    | PMOS + P-channel MOSFET model        |
    +------+-------------------------------+
    | NMF  + N-channel MESFET model        |
    +------+-------------------------------+
    | PMF  + P-channel MESFET model        |
    +------+-------------------------------+

    """

    ##############################################

    def __init__(self, name, modele_type, **parameters):

        self._name = str(name)
        self._model_type = str(modele_type)

        self._parameters = {}
        for key, value in parameters.items():
            if key.endswith('_'):
                key = key[:-1]
            self._parameters[key] = value

    ##############################################

    def clone(self):
        # Fixme: clone parameters ???
        return self.__class__(self._name, self._model_type, **self._parameters)

    ##############################################

    @property
    def name(self):
        return self._name

    @property
    def model_type(self):
        return self._model_type

    @property
    def parameters(self):
        return self._parameters.keys()

    ##############################################

    def __getitem__(self, name):
        return self._parameters[name]

    ##############################################

    def __getattr__(self, name):
        try:
            return self._parameters[name]
        except KeyError as exception:
            if name.endswith('_'):
                return self._parameters[name[:-1]]
            raise exception

    ##############################################

    def __repr__(self):
        return str(self.__class__) + ' ' + self.name

    ##############################################

    def to_spice(self):
        parameters = join_dict(self._parameters)
        return f".model {self._name} {self._model_type} ({parameters})"

    def __str__(self):
        return self.to_spice()

    def to_spectre(self, context=None):
        """Return the Spectre model declaration."""
        from .Spectre import resolve_spectre_model, spectre_identifier, format_spectre_value
        result = resolve_spectre_model(self)
        if result is None:
            return f"// Unsupported model type: {self._model_type} for {self._name}"
        module_name, osdi_file, params = result
        if context is not None:
            context.register_osdi(osdi_file)
        name = spectre_identifier(self._name)
        param_str = ' '.join(f'{k}={v}' for k, v in params.items())
        if param_str:
            return f"model {name} {module_name} {param_str}"
        else:
            return f"model {name} {module_name}"
